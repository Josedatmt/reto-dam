package com.backend.model;

public enum EstadoVacante {
    CREADA, CANCELADA, ASIGNADA
}
