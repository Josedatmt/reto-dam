package com.backend.dto;

import lombok.Data;

public class VacanteDTO {

}
