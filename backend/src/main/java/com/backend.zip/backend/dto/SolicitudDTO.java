package com.backend.dto;


import lombok.Data;

@Data
public class SolicitudDTO {

}