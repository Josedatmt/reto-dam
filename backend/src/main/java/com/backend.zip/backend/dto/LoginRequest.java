package com.backend.dto;

public class LoginRequest {
}
