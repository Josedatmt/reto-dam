package com.backend.dto;

public class RegisterRequest {
}
