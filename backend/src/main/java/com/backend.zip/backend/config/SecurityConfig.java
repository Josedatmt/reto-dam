package com.backend.config;

public class SecurityConfig {
}
